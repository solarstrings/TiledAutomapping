<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="BlockShapes" tilewidth="32" tileheight="32" tilecount="14" columns="7">
 <image source="BlockTileSet.png" width="224" height="64"/>
</tileset>
