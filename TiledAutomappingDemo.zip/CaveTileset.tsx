<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="CaveTileset" tilewidth="32" tileheight="32" tilecount="44" columns="11">
 <image source="CaveTileset.png" width="352" height="128"/>
</tileset>
